#!/bin/bash

wget -N https://raw.githubusercontent.com/c-j-d/lineedit/master/libs/linenoise/linenoise.c
wget -N https://raw.githubusercontent.com/c-j-d/lineedit/master/libs/linenoise/linenoise.h
wget -N https://raw.githubusercontent.com/c-j-d/lineedit/master/libs/linenoise/utf8.c
wget -N https://raw.githubusercontent.com/c-j-d/lineedit/master/libs/linenoise/utf8.h